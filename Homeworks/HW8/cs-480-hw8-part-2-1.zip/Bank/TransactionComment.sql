insert into TransactionComment (TransactionID, Comment) values (1001, 'First');
insert into TransactionComment (TransactionID, Comment) values (1005, 'Birthday Present');
insert into TransactionComment (TransactionID, Comment) values (1021, 'Rent');
insert into TransactionComment (TransactionID, Comment) values (1056, 'Payment for Services');
