insert into AccountType (TypeID, TypeName, InterestRate) values (1, 'Savings', 0.662);
insert into AccountType (TypeID, TypeName, InterestRate) values (2, 'Checking', 0.034);
insert into AccountType (TypeID, TypeName, InterestRate) values (3, 'Money Market', 0.730);
insert into AccountType (TypeID, TypeName, InterestRate) values (4, 'CD', 2.810);