-- Write a trigger or transaction of your choice 
-- to accomplish one of the tasks we discussed or 
-- an idea of your own that a bank would need to perform.   
-- Include a comment at the top containing a sentence or 
-- paragraph describing what the code is supposed to be doing. 

