DROP DATABASE IF EXISTS Bank;
CREATE DATABASE Bank;
USE Bank;

SOURCE /home/codio/workspace/Bank/createBank.sql
SOURCE /home/codio/workspace/Bank/populateBank.sql
